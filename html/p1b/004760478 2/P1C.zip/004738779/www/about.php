<!DOCTYPE html>
<title>CS 143 - Project 1C</title>
<html>
   <body>
      <?php include("navbar.php"); ?>
      <div class="col-md-8 col-md-push-2 about-box" style="height:350px;margin-top:40px">
        <p>Welcome to the CS 143 Demo Project!</p>
        <p>This project was a collaborative effort of Swathi and Shriya towards
        	their Database Management Systems Course!</p>
        <p>This website is a simulation of IMDB's Movie Portal purely in PHP</p>
        <p>We hope you had fun navigating the site!</p>
        <p>Cheers!<p>
      </div>
   </body>
</html>