<!DOCTYPE html>
<title>CS 143 - Project 1C</title>
<html>
   <body>
      <?php include("navbar.php"); ?>
      <div class="col-md-4 col-md-push-4 about-box">
        <p style="line-height:8">Welcome to the CS 143 Demo Project!</p>
      </div>
   </body>
</html>