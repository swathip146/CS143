Member 1: Shriya Sasank
UID: 004738779

1. Worked on the create and load modules.
2. Wrote PHP scripts for actor_info, add_actor, show_actor, search.php
3. Worked on front-end modules.
4. Violations and testing done.

Member 2: Swathi Patnaikuni
UID: 004760478

1. Worked on the querying part of the project.
2. Wrote PHP scripts for movie_info, add_movie, show_movie, add_actor_dir.php
3. Worked on front-end modules.
4. Violations and testing done.